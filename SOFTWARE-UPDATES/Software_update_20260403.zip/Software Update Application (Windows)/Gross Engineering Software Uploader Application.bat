@echo off
title Gross Engineering Autodrive Software Update
color 0A
setlocal enabledelayedexpansion

:: Configuration
set "BAUD_RATE=115200"
set "HEX_FILE="

echo.
echo ============================================================
echo      GROSS ENGINEERING AUTODRIVE SOFTWARE UPDATE
echo ============================================================
echo.

:: Auto-detect hex file
echo Looking for firmware file...
set HEX_COUNT=0
for %%f in (*.hex) do (
    set /a HEX_COUNT+=1
    set "HEX_FILE=%%f"
)

if %HEX_COUNT%==0 (
    echo ERROR: No firmware file found!
    echo Please make sure the .hex file is in the same folder as this program.
    echo.
    pause
    exit /b 1
)

if %HEX_COUNT% gtr 1 (
    echo WARNING: Multiple firmware files found!
    echo Please keep only one .hex file in this folder.
    echo.
    pause
    exit /b 1
)

echo Found firmware: %HEX_FILE%
echo.
echo ============================================================
echo STEP 1: Connect your Autodrive controller to USB
echo.
echo STEP 2: Wait a few seconds for Windows to recognize it
echo.
echo STEP 3: Press any key to continue...
echo.
pause >nul

:: Detect available COM ports and try to find Arduino automatically
echo.
echo Scanning for Autodrive controller...
echo.
set PORT_COUNT=0
set "ARDUINO_PORT="

:: First, try to auto-detect Arduino (CH340) using PowerShell
for /f "tokens=*" %%a in ('powershell -Command "$ErrorActionPreference='SilentlyContinue'; Get-CimInstance -ClassName Win32_PnPEntity | Where-Object {$_.Name -like '*CH340*' -or $_.Name -like '*Arduino*'} | ForEach-Object {if($_.Name -match 'COM(\d+)'){$matches[0]}}"') do (
    set "ARDUINO_PORT=%%a"
)

:: Build list of all COM ports as backup
for /f "tokens=3" %%a in ('reg query HKLM\HARDWARE\DEVICEMAP\SERIALCOMM 2^>nul') do (
    set /a PORT_COUNT+=1
    set "PORT_!PORT_COUNT!=%%a"
    echo    [!PORT_COUNT!] %%a
    
    :: If we didn't auto-detect but this matches our Arduino port guess, save it
    if not defined ARDUINO_PORT (
        if !PORT_COUNT! EQU %PORT_COUNT% set "ARDUINO_PORT=%%a"
    )
)

if %PORT_COUNT%==0 (
    echo.
    echo ERROR: No COM ports found!
    echo.
    echo Please check:
    echo - Autodrive controller is plugged into a USB port
    echo - USB cable is working (try a different cable^)
    echo - CH340 drivers are installed
    echo.
    echo Would you like to install CH340 drivers now? (Y/N^)
    set /p INSTALL_DRIVER=
    if /i "!INSTALL_DRIVER!"=="Y" (
        if exist "CH341SER.EXE" (
            start CH341SER.EXE
            echo.
            echo Please install the driver, then restart this program.
        ) else if exist "tools\CH341SER.EXE" (
            start tools\CH341SER.EXE
            echo.
            echo Please install the driver, then restart this program.
        ) else (
            echo Driver installer not found.
            echo Please download CH340 drivers from:
            echo https://github.com/sparkfun/CH340_drivers
        )
    )
    echo.
    pause
    exit /b 1
)

:: If Arduino was auto-detected, use it automatically
if defined ARDUINO_PORT (
    echo.
    echo Autodrive controller found on: %ARDUINO_PORT%
    echo Using this port automatically...
    set "SELECTED_PORT=%ARDUINO_PORT%"
    timeout /t 2 >nul
    echo.
    goto UPLOAD
)

:: If only one COM port exists, use it automatically
if %PORT_COUNT%==1 (
    set "SELECTED_PORT=!PORT_1!"
    echo.
    echo Only one COM port found: !SELECTED_PORT!
    echo Using this port automatically...
    timeout /t 2 >nul
    echo.
    goto UPLOAD
)

:: Multiple ports and couldn't auto-detect - ask user
echo.
echo Multiple COM ports found. Please select your Autodrive controller:
echo.

echo.
echo Enter the number in brackets [1-%PORT_COUNT%]: 
set /p PORT_CHOICE=

:: Remove brackets, COM prefix and spaces if user typed them
set "PORT_CHOICE=%PORT_CHOICE:[=%"
set "PORT_CHOICE=%PORT_CHOICE:]=%"
set "PORT_CHOICE=%PORT_CHOICE:COM=%"
set "PORT_CHOICE=%PORT_CHOICE:com=%"
set "PORT_CHOICE=%PORT_CHOICE: =%"

:: Check if empty
if not defined PORT_CHOICE goto INVALID_CHOICE

:: Check if it's within valid range
if %PORT_CHOICE% LSS 1 goto INVALID_CHOICE
if %PORT_CHOICE% GTR %PORT_COUNT% goto INVALID_CHOICE

:: Get the selected port
set "SELECTED_PORT=!PORT_%PORT_CHOICE%!"

:: Verify we got a valid port
if not defined SELECTED_PORT goto INVALID_CHOICE

echo.
echo Selected: %SELECTED_PORT%
echo.
goto UPLOAD

:INVALID_CHOICE
echo Invalid selection! Please run the program again.
pause
exit /b 1

:UPLOAD
:: Upload firmware
cls
echo.
echo ============================================================
echo      GROSS ENGINEERING AUTODRIVE SOFTWARE UPDATE
echo ============================================================
echo.
echo Connected to: %SELECTED_PORT%
echo Firmware: %HEX_FILE%
echo.
echo ============================================================
echo.
echo [1/3] Connecting to controller...
timeout /t 1 >nul
echo [2/3] Uploading software (this may take 30-60 seconds)...
echo.
echo       Please do NOT disconnect the USB cable!
echo.

:: Run the upload (suppress verbose output)
tools\avrdude.exe -C tools\avrdude.conf -patmega2560 -cwiring -P%SELECTED_PORT% -b%BAUD_RATE% -D -Uflash:w:"%HEX_FILE%":i >nul 2>&1

echo [3/3] Verifying update...
timeout /t 1 >nul
echo.

if %errorlevel% equ 0 (
    color 0A
    echo.
    echo ============================================================
    echo          SUCCESS! Software updated successfully!
    echo ============================================================
    echo.
    echo Your Autodrive controller has been updated and is ready to use.
    echo You can now disconnect the USB cable.
    echo.
) else (
    color 0C
    echo.
    echo ============================================================
    echo                   UPDATE FAILED!
    echo ============================================================
    echo.
    echo Please try the following:
    echo 1. Unplug and replug the controller USB cable
    echo 2. Wait 10 seconds, then run this program again
    echo 3. Try selecting a different COM port
    echo 4. Try a different USB port on your computer
    echo.
    echo If problems persist, please contact Gross Engineering support.
    echo.
)

pause